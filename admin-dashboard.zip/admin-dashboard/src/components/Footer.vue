<template>
    <footer class="bg-dark text-white text-center py-3 mt-auto">
      <p>&copy; 2024 Admin Panel | All Rights Reserved</p>
    </footer>
  </template>
  
  <script>
  export default {
    name: "Footer",
  };
  </script>
  
  <style scoped>
  /* Footer styling (optional) */
  </style>
  