<template>
  <router-view /> <!-- Chỉ cần router-view ở đây -->
</template>

<script>
export default {
  name: 'App'
};
</script>

<style scoped>
/* Global styles */
</style>
