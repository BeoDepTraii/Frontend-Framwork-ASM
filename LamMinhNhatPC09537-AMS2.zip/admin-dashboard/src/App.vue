<template>
  <div id="app" class="d-flex flex-column">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style scoped>
/* Global styles */
</style>
