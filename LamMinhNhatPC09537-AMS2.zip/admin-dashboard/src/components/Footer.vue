<template>
  <footer class="footer bg-light text-center py-3">
    <p class="mb-0">&copy; 2024 Admin Dashboard | All Rights Reserved</p>
  </footer>
</template>

<script>
export default {
  name: 'Footer',
};
</script>

<style scoped>
/* Footer styling */
.footer {
  margin-top: auto;
}
</style>
